import json
import boto3


def main (event, context):
	payload = event
	payload = payload["Records"][0]
	body = payload["body"]
	body = body.replace('\n', '')
	body = json.loads(body)
	query = body["body-json"]

	client = boto3.resource('dynamodb', region_name="us-east-1")
	table = client.Table("AWSDynamoDB-g3")
	
	data = table.scan()

	resp = {
		"statusCode": 200,
		"headers": {
			"Access-Control-Allow-Origin": "*",
		},
		"body": json.dumps(data)
	}

	return resp